#include <fstream>
#include <iostream>
#include <thread>
#include <sys/time.h>
#include <sys/wait.h>

#include "BoundedBuffer.h"
#include "common.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "TCPRequestChannel.h"

#define RED     "\033[1;31m"
#define GREEN	"\033[1;32m"
#define NC      "\033[0m"

#define ECGNO 1     // ecgno to use for datamsgs

using namespace std;

struct response {
    int p_no;
    double data;
};

void patient_thread_function (BoundedBuffer* request_buffer, int p_no , int n) {
    for (int i = 0; i < n; i++) {
        datamsg msg = datamsg(p_no, i * 0.004, ECGNO);
        request_buffer->push((char*) &msg, sizeof(datamsg));
    }
}

void file_thread_function (BoundedBuffer* request_buffer, TCPRequestChannel* chan, int buffer_size, string filename) {
    
    filemsg fm(0, 0);
    char msg[sizeof(filemsg) + filename.size() + 1];
    memcpy(msg, &fm, sizeof(filemsg));
    strcpy(msg + sizeof(filemsg), filename.c_str());
    chan->cwrite(msg, sizeof(msg));
    __int64_t file_size;
    chan->cread(&file_size, sizeof(__int64_t));

    FILE* fp = fopen(("received/" + filename).c_str(), "w");
    fseek(fp, file_size, SEEK_SET);
    fclose(fp);

    int chunks = floor(file_size / buffer_size);
	int length = buffer_size;

    for (int i = 0; i < chunks + 1; ++i) {
        if (i == chunks) {
            length = file_size % chunks;
        }
        
        ((filemsg*)msg)->offset = i * buffer_size;
        ((filemsg*)msg)->length = length;

        request_buffer->push(msg, sizeof(msg));
    }
}

void worker_thread_function (BoundedBuffer* request_buffer, BoundedBuffer* response_buffer, TCPRequestChannel* channel, int m) {
    while (true) {
        char request[m];
        request_buffer->pop(request, m);
        MESSAGE_TYPE m = *((MESSAGE_TYPE*) request);
        
        if (m == DATA_MSG) {
            channel->cwrite((datamsg*) request, sizeof(datamsg));
            double data;
            channel->cread(&data, sizeof(double));
            
            response r = {((datamsg*)request)->person, data};
            response_buffer->push((char*) &r, sizeof(response));
        }
        else if (m == FILE_MSG) {
            filemsg* fm = (filemsg*) request;
            //cout << fm->length << "\t" << fm->mtype << "\t" << fm->offset << endl;
            string filename = (char*)(fm + 1);
            channel->cwrite(request, sizeof(request));
            if (fm->length > 0) {
                char data[fm->length];
                channel->cread(&data, fm->length);

                FILE* fp = fopen(("received/" + filename).c_str(), "r+");

                fseek(fp, fm->offset, SEEK_SET);
                fwrite(data, fm->length, 1, fp);
                fclose(fp);
            }        
        }
        else if (m == QUIT_MSG) {
            channel->cwrite((datamsg*) request, sizeof(datamsg));
            return;
        }
    }
}

void histogram_thread_function (BoundedBuffer* response_buffer, HistogramCollection* hc) {
    while (true) {
        response r;
        response_buffer->pop((char*) &r, sizeof(response));

        if(r.p_no < 0) {
            return;
        }
        else {
            hc->update(r.p_no, r.data);
        }
    }
}

int main (int argc, char* argv[]) {
    int n = 1000;	        // default number of requests per "patient"
    int p = 10;		        // number of patients [1,15]
    int w = 100;	        // default number of worker threads
	int h = 20;		        // default number of histogram threads
    int b = 20;		        // default capacity of the request buffer (should be changed)
	int m = MAX_MESSAGE;	// default capacity of the message buffer

    string a = "127.0.0.1"; // default value IP
    string r = "8080";      // default port
	string f = "";	        // name of file to be transferred
    
    // read arguments
    int opt;
	while ((opt = getopt(argc, argv, "n:p:w:h:b:m:f:a:r:")) != -1) {
		switch (opt) {
			case 'n':
				n = atoi(optarg);
                break;
			case 'p':
				p = atoi(optarg);
                break;
			case 'w':
				w = atoi(optarg);
                break;
			case 'h':
				h = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
                break;
			case 'm':
				m = atoi(optarg);
                break;
			case 'f':
				f = optarg;
                break;
            case 'a':
                a = optarg;
                break;
            case 'r':
                r = optarg;
                break;
		}
	}
    
	// initialize overhead
    BoundedBuffer request_buffer(b);
    BoundedBuffer response_buffer(b);
	HistogramCollection hc;
    TCPRequestChannel* file_channel;

    vector<thread> patient_threads;         // vector of patient threads (if data, p elements; if file, 1 filethread)
    vector<TCPRequestChannel*> channels;    // array of FIFOs (w elements)  
    vector<thread> worker_threads;          // array of worker threads (w elements)
    vector<thread> histogram_threads;       // array of histogram_threads (if data, h elements, if;file, zero elements)

    // making histograms and adding to collection
    for (int i = 0; i < p; i++) {
        Histogram* h = new Histogram(10, -2.0, 2.0);
        hc.add(h);
    }

	// record start time
    struct timeval start, end;
    gettimeofday(&start, 0);

    /* create all threads here */

    // if DATA, create p patient threads (store in patient array)
    if(f.empty()) {
        for (int i = 0; i < p; i++) {
            patient_threads.push_back(thread(patient_thread_function, &request_buffer, i + 1, n));
        }
    }

    // create w worker_threads (store worker array)
    for (int i = 0; i < w; i++) {
        TCPRequestChannel* thread_chan = new TCPRequestChannel(a, r);
        worker_threads.push_back(thread(worker_thread_function, &request_buffer, &response_buffer, thread_chan, m));
        channels.push_back(thread_chan);
    }

    // if FILE, create 1 file_thread (store in patient array)
    if (!f.empty()) {
        file_channel = new TCPRequestChannel(a, r);
        patient_threads.push_back(thread(file_thread_function, &request_buffer, file_channel, m, f));
    }

    // if DATA, create h hist_threads (store hist array)
    if(f.empty()) {
        for (int i = 0; i < h; i++) {
            histogram_threads.push_back(thread(histogram_thread_function, &response_buffer, &hc));
        }
    }

	/* join all threads here */

    // join patient threads
    if(f.empty()) {
        for (int i = 0; i < p; i++) {
            patient_threads[i].join();
        }
    }

    // join file thread
    else {
        patient_threads[0].join();
    }

    // push w quit_msg to request buffer
    for (int i = 0; i < w; i++) {
        MESSAGE_TYPE q = QUIT_MSG;
        request_buffer.push((char*) &q, sizeof(MESSAGE_TYPE));
    }

    // join worker threads
    for (int i = 0; i < w; i++) {
        worker_threads[i].join();
    }

    // push h quit_msg to response buffer
    response quit_pair = {-1, 0.0};
    for (int i = 0; i < h; i++) {
        response_buffer.push((char*) &quit_pair, sizeof(response));
    }

    // join histogram threads
    if (f.empty()) {
        for (int i = 0; i < h; i++) {
            histogram_threads[i].join();
        }
    }

	// record end time
    gettimeofday(&end, 0);

    // print the results
	if (f == "") {
		hc.print();
	}
    int secs = ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) / ((int) 1e6);
    int usecs = (int) ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) % ((int) 1e6);
    cerr << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;

    // deallocate channel references    
    for(size_t i = 0; i < channels.size(); i++) {   
        delete channels[i];         //worker channels
    }
    if (!f.empty()) {
        delete file_channel;            // file channel
    }
    cerr << "All Done!" << endl;
}