#include "TCPRequestChannel.h"

#include <sys/socket.h>
#include <arpa/inet.h>

#include <unistd.h>
#include <netdb.h>

using namespace std;

TCPRequestChannel::TCPRequestChannel (const std::string _ip_address, const std::string _port_no) {
    // if server side
    if (_ip_address.empty()) {

        // create socket with _port_no with domain (AF_INET), type (SOCK_STREAM), and protocol (0)
        //cerr << "Server - Create Socket" << endl;
        if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("socket failed");
            exit(EXIT_FAILURE);
        }

        struct sockaddr_in sockaddr;
        sockaddr.sin_addr.s_addr = INADDR_ANY;
        sockaddr.sin_family = AF_INET;
        sockaddr.sin_port = htons(stoi(_port_no));

        // bind to assign address (sockaddr_in, inet_pton) to socket to allow server to listen on port_no
        //cerr << "Server - Bind" << endl;
        if (bind(sockfd, (struct sockaddr*) &sockaddr, sizeof(sockaddr)) < 0) {
            perror("bind failed");
            exit(EXIT_FAILURE);
        }

        // mark socket as listening
        //cerr << "Server - Listen" << endl;
        if (listen(sockfd, 50) < 0) {
            perror("listening failed");
            exit(EXIT_FAILURE);
        }
        
    }
    // if client side
    else {
        // create socket with domain, type, and protocol
        //cerr << "Client - Create socket" << endl;
        if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("socket failed");
            exit(EXIT_FAILURE);
        }

        // convert IP address string to int (inet_pton)
        struct sockaddr_in sockaddr;

        //cerr << "Client - Convert address" << endl;
        if (inet_pton(AF_INET, _ip_address.c_str(), &sockaddr.sin_addr) <= 0) {
            perror("invalid address");
            exit(EXIT_FAILURE);
        }
        sockaddr.sin_port = htons(stoi(_port_no));
        sockaddr.sin_family = AF_INET;

        // connect socket to an IP address of the server
        //cerr << "Client - Connect" << endl;
        
        if (connect(sockfd, (struct sockaddr*)&sockaddr, sizeof(sockaddr)) < 0) {
            perror("connection failed");
            exit(EXIT_FAILURE);
        }

        //cerr << "Client - Connected" << endl;
    }
}

TCPRequestChannel::TCPRequestChannel (int _sockfd) {
    this->sockfd = _sockfd;
}

TCPRequestChannel::~TCPRequestChannel () {
    close(sockfd);
}

int TCPRequestChannel::accept_conn () {
    int fd;
    struct sockaddr_storage client;
    socklen_t size = sizeof(client);
    if((fd = accept(sockfd, (struct sockaddr*) &client, (socklen_t*) &size)) < 0) {
        perror("accept failed");
        exit(EXIT_FAILURE);
    }
    //cerr << "Server - Connected" << endl;
    return fd;
}

int TCPRequestChannel::cread (void* msgbuf, int msgsize) {
    return recv(sockfd, msgbuf, msgsize, 0);
}

int TCPRequestChannel::cwrite (void* msgbuf, int msgsize) {
    return send(sockfd, msgbuf, msgsize, 0);
}
