#include <iostream>
#include <fstream>

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#include <vector>
#include <string>

#include "Tokenizer.h"

// all the basic colours for a shell prompt
#define RED     "\033[1;31m"
#define GREEN	"\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE	"\033[1;34m"
#define WHITE	"\033[1;37m"
#define NC      "\033[0m"

// Define std file descriptors & full permissions
#define STDOUT  1
#define STDIN   0
#define FULLPERM 0666

using namespace std;

int main () {
    //char* prevdir = getcwd(NULL, 0);
    int stdin = dup(STDOUT);
    int stdout = dup(STDIN);

    char* cwd;
    char* owd = getcwd(NULL, 0);

    vector<int> processes;

    for (;;) {

        // Print out shell header
        time_t rawtime;
        time(&rawtime);
        cwd = getcwd(NULL, 0);
        printf(GREEN "%.12s " BLUE "%s" YELLOW " %s$" NC " ", &ctime(&rawtime)[4], cwd, getenv("USER"));
        
        
        // get user inputted command
        string input;
        getline(cin, input);

        // handle background processes
        for (int i = processes.size() - 1; i >= 0; --i) {
            if (waitpid(processes[i], NULL, WNOHANG) > 0) {
                processes.erase(processes.begin() + i);
            }
        }

        // print exit message and break out of infinite loop
        if (input == "exit") {  
            free(cwd);
            cerr << RED << "Now exiting shell..." << endl << "Goodbye" << NC << endl;
            break;
        }

        // get tokenized commands from user input
        Tokenizer tknr(input);
        // continue to next prompt if input had an error
        if (tknr.hasError()) {  
            continue;
        }

        // print out every command token-by-token on individual lines
        for (auto cmd : tknr.commands) {
            cerr << GREEN << cmd << NC << "\t";
            for (auto str : cmd->args) {
                cerr << "|" << str << "| ";
            }
            if (cmd->hasInput()) {
                cerr << "in< " << cmd->in_file << " ";
            }
            if (cmd->hasOutput()) {
                cerr << "out> " << cmd->out_file << " ";
            }
            cerr << endl;
        }
            
        // Handle chdir
        vector<string> fcmd = tknr.commands.front()->args;
        if (fcmd.front() == "cd") {
            // Go pack to previous directory
            if (fcmd.at(1) == "-") {
                chdir(owd);
            }
            // Gp to specified directory
            else {
                chdir(fcmd.at(1).c_str());
            }
            owd = cwd;
            continue;
        }

        

        for (Command* cmd : tknr.commands) {
            
            int fds[2];
            if (tknr.commands.back() != cmd) {
                cerr << "Open pipe" << endl;
            }
            if (tknr.commands.back() != cmd && pipe(fds) < 0) {
                perror("Pipe failed to open");
                exit(2);
            }

            
            
            pid_t pid = fork();
            // error check
            if (pid < 0) {  
                perror("Cannot fork");
                exit(2);
            }

            // if child process
            if (pid == 0) {
                // Parse Command
                cerr << "\nIn child:" << endl;
                char** args = new char*[cmd->args.size() + 1];
                for (size_t i = 0; i < cmd->args.size(); ++i) {
                    args[i] = (char*) cmd->args.at(i).c_str();
                }
                args[cmd->args.size()] = NULL;

                // Redirect input on first command if necessary
                if (cmd->hasInput() && tknr.commands.front() == cmd) {
                    cerr << "Open file " << GREEN << cmd->in_file << NC << " for input, overwrite STDIN with input fd" << endl;
                    int fd = open(cmd->in_file.c_str(), O_RDONLY | O_CREAT, FULLPERM);
                    if (!fd) {
                        perror("No input file found");
                        exit(2);
                    }
                    dup2(fd, STDIN);
                }

                // Redirect output on last command if necessary
                if(tknr.commands.back() == cmd) {
                    if (cmd->hasOutput()) {    
                        cerr << "Open file " << GREEN << cmd->out_file << NC << " for output, overwrite STDOUT with output fd" << endl;
                        int fd = open(cmd->out_file.c_str(), O_RDWR | O_TRUNC | O_CREAT, FULLPERM);
                        if (!fd) {
                            perror("Output file could not be opened");
                            exit(2);
                        }
                        dup2(fd, STDOUT);
                    }
                }
                
                // Use pipe for input if >1 command
                else{
                    cerr << "Child output redirected from STDOUT -> PipeOut" << endl;
                    dup2(fds[1], STDOUT);   // Child output redirected to pipe - instead of STDOUT
                    cerr << "Close read end of pipe in child" << endl;
                    close(fds[0]);          // Close read end of pipe in child
                }
                

                cerr << "Execute command" << endl;
                execvp(args[0], args);  // execute

                delete[] args;
                perror("Exec 1 failed");
                exit(2);
            }
            // if in parent
            else {
                cerr << "\nIn parent:" << endl;

                // TODO: Implement backgound command (&)
                if (cmd->isBackground()) {
                    // check for backgound process - add pid to vector if background and then don't wait in background
                    processes.push_back(pid);
                }
                
                // Redirect parent input to pipe if not first command (i.e. we have commands piped together)
                if (tknr.commands.back() != cmd) {
                    cerr << "Parent input redirected from STDIN -> PipeIn" << endl;
                    dup2(fds[0], STDIN);     // Parent input redirected to pipe - instead of STDIN
                    cerr << "Close write end of pipe in parent" << endl;
                    close(fds[1]);           // Close write end of pipe in parent
                }


                // Wait for child to finish
                int status = 0;
                if (!cmd->isBackground() && tknr.commands.back() == cmd) {
                    cerr << "Waiting for child to finish" << endl;
                    waitpid(pid, &status, 0);
                }
                
                cerr << "Child finished" << endl;
                if (status > 1) {  // exit if child didn't exec properly
                    perror("Error: Child exit with status " + status);
                    exit(status);
                }
            }

            
        }

        // restore stdout outside of loop, close open files
        dup2(stdin, STDIN);
        free(cwd); 
       
    }

    free(owd);
}
