/*
	Original author of the starter code
    Tanzir Ahmed
    Department of Computer Science & Engineering
    Texas A&M University
    Date: 2/8/20
	
	Please include your Name, UIN, and the date below
	Name: Alexander Warren
	UIN: 130008745
	Date: 02/03/2022
*/
#include "common.h"
#include "FIFORequestChannel.h"
#include <chrono>

using namespace std;
using namespace std::chrono;

int buffercapacity = MAX_MESSAGE;

int main (int argc, char *argv[]) {
	
	
	
	int opt;
	int p = -1;
	double t = -1;
	int e = -1;
	bool create_new_channel = false, single = false, multiple = false;
	
	string filename = "";
	while ((opt = getopt(argc, argv, "p:t:e:f:m:c")) != -1) {
		switch (opt) {
			case 'p':
				p = atoi (optarg);
				multiple = true;
				break;
			case 't':
				t = atof (optarg);
				break;
			case 'e':
				e = atoi (optarg);
				single = true;
				multiple = false;
				break;
			case 'f':
				filename = optarg;
				break;
			case 'm':
				buffercapacity = atoi (optarg);
				cout << "Change client buffer capacity to " << buffercapacity << endl;
				break;
			case 'c':
				create_new_channel = true;
				break;
		}
	}

	int pid = fork();
	if (pid == -1) {
		cout << "Error forking" << endl;
	}
	else if (pid == 0) {
		execvp("./server",argv);
	}
	else {
		cout << "Client started" << endl;
	}

    FIFORequestChannel chan("control", FIFORequestChannel::CLIENT_SIDE);
	FIFORequestChannel* current_chan = &chan;

	cout << "Control pipe connected CLIENT_SIDE" << endl;

    char buf[MAX_MESSAGE]; // 256
	
	char buf2[40];
	if(create_new_channel) {
		cout << "Requesting new channel CLIENT_SIDE" << endl;
		MESSAGE_TYPE x = NEWCHANNEL_MSG;
		chan.cwrite(&x, sizeof(MESSAGE_TYPE));
		chan.cread(&buf2, 40);
		cout << "New channel name " << buf2 << " CLIENT_SIDE" << endl;
		current_chan = new FIFORequestChannel(buf2, FIFORequestChannel::CLIENT_SIDE);
	}

	// create_new_channel? new_chan:
	// Single datapoint
	if (single) {
		datamsg x(p, t, e);
		memcpy(buf, &x, sizeof(datamsg));
		auto start = high_resolution_clock::now();
		(*current_chan).cwrite(buf, sizeof(datamsg)); // question
		double reply;
		(*current_chan).cread(&reply, sizeof(double)); //answer
		cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
		cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;
	}

	// Multiple datapoints (whole file)
	else if (multiple){
		ofstream fs("received/x1.csv");
		cout << "Writing multiple datapoints ";
		auto start = high_resolution_clock::now();
		for (t = 0; t < 4; t += 0.004) {
			if ((int)(t /0.004) % 100 == 0) { cout << "." << flush;}
			datamsg x(p, t, 1);
			double dpt1, dpt2;
			
			(*current_chan).cwrite(&x, sizeof(datamsg)); // question
			(*current_chan).cread(&dpt1, sizeof(double)); //answer

			x.ecgno = 2;

			(*current_chan).cwrite(&x, sizeof(datamsg)); // question
			(*current_chan).cread(&dpt2, sizeof(double)); //answer

			fs << t << ", " << dpt1 << ", " << dpt2 << "\n";
		}
		cout << endl;
		cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
		fs.close();
	}
	
	else if (!filename.empty()) {
		int len = sizeof(filemsg) + (filename.size() + 1);
		cout << "Requesting file " << filename << endl;

		// Get filesize
		filemsg fm(0, 0);

		char* buf2 = new char[len];
		memcpy(buf2, &fm, sizeof(filemsg));
		strcpy(buf2 + sizeof(filemsg), filename.c_str());
		chan.cwrite(buf2, len);

		;

		__int64_t reply;
		chan.cread(&reply, sizeof(__int64_t));
		cout << "File size of \"" << filename << "\" is " << reply << " bytes" << endl;
		
		int chunks = floor(reply / buffercapacity);
		int length = buffercapacity;
		
		
		cout << "File transfer in " << chunks + 1 << " requests" << endl;
		

		string out_file = "received/" + filename;
		ofstream ofs(out_file, ios::binary);

		if (!ofs) {
			cout << "Error: Filestream not started" << endl;
		}
		else {
			cout << "Creating output file \"" << out_file << "\"" << endl;
		}

		auto start = high_resolution_clock::now();
		for (int i = 0; i < chunks + 1; ++i) {
			//cout << "Sending request " << i + 1 << " of " << chunks + 1 << endl;
			// Update filemsg
			((filemsg*)buf2)->offset = i * buffercapacity;
			if (i == chunks) {
				// Calculate size of last (partial) chunk
				length = reply % chunks;
			}
			((filemsg*)buf2)->length = length;

			// send chunk request
			(*current_chan).cwrite(buf2, len);
			
			// read reply and write results to file
			char* data = new char[buffercapacity];
			(*current_chan).cread(data, length);
			ofs.write(data, length);
			delete[] data;

		}
		ofs.close();
		delete[] buf2;

		cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
	}
	

	// closing main channel    
	cout << "closing channel \"" << chan.name() << "\"" << endl;
	MESSAGE_TYPE m = QUIT_MSG;
	chan.cwrite(&m, sizeof(MESSAGE_TYPE));

	// closing the channel   
	if (create_new_channel) {
		cout << "closing channel \"" << (*current_chan).name() << "\"" << endl;
		(*current_chan).cwrite(&m, sizeof(MESSAGE_TYPE));
		delete current_chan;
	}

	

}