#include <sys/mman.h>

#include "SHMRequestChannel.h"

using namespace std;


SHMQueue::SHMQueue (const string _name, int _length) : name(_name), length(_length) {
    // open (and possibly create) the shared memory file using shm_open
    int fd = shm_open(_name.c_str(), O_RDWR | O_CREAT, 0600);
    // set the size of the shm with ftruncate
    ftruncate(fd, length);
    // mmap
    segment = (char*) mmap(NULL, _length, PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0);
    // close the shm
    close(fd);
    // create two semaphores
    recv_done = sem_open(("/" + name + "read").c_str(), O_CREAT, 0600, 1);
    if (recv_done == SEM_FAILED) {
        perror("failed to open recv_done");
        exit(EXIT_FAILURE);
    }
    send_done = sem_open(("/" + name + "write").c_str(), O_CREAT, 0600, 0);
    if (send_done == SEM_FAILED) {
        perror("failed to open send_done");
        exit(EXIT_FAILURE);
    }
    
}

SHMQueue::~SHMQueue () {
    // unmap parent's copy of the shm using munmap
    munmap(segment, length);
    // shm.unlink
    shm_unlink(name.c_str());

    // for both sems, call close and unlink
    sem_close(recv_done);
    sem_close(send_done);
    sem_unlink(("/" + name + "read").c_str());
    sem_unlink(("/" + name + "write").c_str());
}

int SHMQueue::shm_receive (void* msgbuf, int msgsize) {
    // memcopy, synch with both semaphores

    //cout << "shm_recieve" << endl;
    sem_wait(send_done);
    //cout << "reading" << endl;
    memcpy(msgbuf, segment, msgsize);
    sem_post(recv_done);

    return msgsize;
}

int SHMQueue::shm_send (void* msgbuf, int msgsize) {
    // memcopy, synch with both semaphores

    //cout << "shm_send" << endl;
    sem_wait(recv_done);
    //cout << "writing" << endl;
    memcpy(segment, msgbuf, msgsize);
    sem_post(send_done);

    return msgsize;
}

SHMRequestChannel::SHMRequestChannel (const std::string _name, const Side _side, size_t msg_size) : RequestChannel(_name, _side) {
    if (_side == CLIENT_SIDE) {
        read  = new SHMQueue(("/" + _name + "1").c_str(), msg_size);
        write = new SHMQueue(("/" + _name + "2").c_str(), msg_size);
    }
    else {
        write = new SHMQueue(("/" + _name + "1").c_str(), msg_size);
        read  = new SHMQueue(("/" + _name + "2").c_str(), msg_size);
    }

}
SHMRequestChannel::~SHMRequestChannel () {
    delete read;
    delete write;
}

int SHMRequestChannel::cread (void* msgbuf, int msgsize) {
    return read->shm_receive(msgbuf, msgsize);
}
int SHMRequestChannel::cwrite (void* msgbuf, int msgsize) {
    return write->shm_send(msgbuf, msgsize);
}