#ifndef _MQREQUESTCHANNEL_H_
#define _MQREQUESTCHANNEL_H_

#include "RequestChannel.h"
#include <mqueue.h>


class MQRequestChannel : public RequestChannel {
// TODO: declare derived components of MQRequestChannel from RequestChannel
    private:
        // variable
        size_t msg_size;
        
        mqd_t write;
        mqd_t read;

        std::string mq_name_1;
        std::string mq_name_2;

        //helper method to open mqueue - create mq_attr struct, pq_open with required mode (incl O_CREAT) (error check -1)
        int open_mq(std::string _name, int mode);

    public:
        MQRequestChannel (const std::string _name, const Side _side, size_t msg_size);     // name has "/" appended, opem two mqueue dependant size
        ~MQRequestChannel ();   // mq_close, athen mq_unlink

        
        int cread (void* msgbuf, int msgsize);
        int cwrite (void* msgbuf, int msgsize);
};

#endif
