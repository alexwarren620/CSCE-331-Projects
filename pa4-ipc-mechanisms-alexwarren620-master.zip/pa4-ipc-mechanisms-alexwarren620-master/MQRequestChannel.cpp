#include <mqueue.h>

#include "MQRequestChannel.h"

using namespace std;

int MQRequestChannel::open_mq(std::string _name, int mode) {
    mq_attr attr{};
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = msg_size;
    mqd_t fd = mq_open(_name.c_str(), mode | O_CREAT, 0600, &attr);
    if (fd == -1) {
        perror("failed to open mq");
        exit(EXIT_FAILURE);
    }
    return fd;
}

MQRequestChannel::MQRequestChannel (const std::string _name, const Side _side, size_t _msg_size) : RequestChannel(_name, _side),  msg_size(_msg_size) {     // name has "/" appended, opem two mqueue dependant size
    mq_name_1 = "/" + _name + "1";
    mq_name_2 = "/" + _name + "2";

    

    if(_side == CLIENT_SIDE) {
        //cout << "open mq " << _name <<" CLIENT_SIDE" << endl;
        read  = open_mq(mq_name_1, O_RDONLY);
        write = open_mq(mq_name_2, O_WRONLY);
    }
    else {
        //cout << "open mq " << _name <<" SERVER_SIDE" << endl;
        read  = open_mq(mq_name_2, O_RDONLY);
        write = open_mq(mq_name_1, O_WRONLY);
    }
}

MQRequestChannel::~MQRequestChannel () {
    //cout << "closing mq" << endl;
    mq_close(read);
    mq_close(write);

    mq_unlink(mq_name_1.c_str());
    mq_unlink(mq_name_2.c_str());
}

int MQRequestChannel::cread (void* msgbuf, int msgsize) {

    //return mq_receive(read, (char*) msgbuf, msg_size, NULL);

    
    //cout << "read " << msgsize << "/" << msg_size << " bytes" << endl;
    char buf[msg_size];
    int b = mq_receive(read, (char*) buf, msg_size, NULL);
    if (b == -1) {
        perror("cread buffer size mismatch");
        exit(EXIT_FAILURE);
    }

    memcpy(msgbuf, buf, msgsize);

    return b;
    
}
int MQRequestChannel::cwrite (void* msgbuf, int msgsize) {
    //return mq_send(write, (char*) msgbuf, msg_size, 0);
    
    //cout << "write " << msgsize << "/" << msg_size << " bytes" << endl;
    char buf[msg_size];
    memcpy(buf, msgbuf, msgsize);

    int b = mq_send(write, (char*) buf, msg_size, 0);
    if (b == -1) {
        perror("cwrite buffer size mismatch");
        exit(EXIT_FAILURE);
    }

    return b;
    
}