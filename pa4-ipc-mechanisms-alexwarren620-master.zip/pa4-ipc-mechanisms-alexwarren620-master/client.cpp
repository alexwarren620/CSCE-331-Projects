// your PA1 client code here

#include "common.h"
#include "FIFORequestChannel.h"
#include "MQRequestChannel.h"
#include "SHMRequestChannel.h"
#include <chrono>

using namespace std;
using namespace std::chrono;

int main (int argc, char *argv[]) {
	
	int opt;
	int p = 0, e = 0, c = 0, m = MAX_MESSAGE;

	double t = 0.0;
	bool single = false, multiple = false;
	
	string filename = "", i = "f";
	while ((opt = getopt(argc, argv, "i:p:t:e:f:m:c:")) != -1) {
		switch (opt) {
			case 'p':
				p = atoi (optarg);
				multiple = true;
				break;
			case 't':
				t = atof (optarg);
				break;
			case 'e':
				e = atoi (optarg);
				single = true;
				multiple = false;
				break;
			case 'f':
				filename = optarg;
				break;
			case 'm':
				m = atoi (optarg);
				break;
			case 'c':
				c = atoi(optarg);
				break;
			case 'i':
				i = optarg;
				break;
		}
	}

	int pid = fork();
	if (pid == -1) {
		cout << "Error forking" << endl;
	}
	else if (pid == 0) {
		execl("./server", "./server", "-m", (char*) to_string(m).c_str(), "-i", (char*) i.c_str(), nullptr);
	}

	RequestChannel* control_chan;
	
	if (i == "f") {
		control_chan = new FIFORequestChannel("control", RequestChannel::CLIENT_SIDE);
	}
	else if (i == "q") {
		control_chan = new MQRequestChannel("control", RequestChannel::CLIENT_SIDE, m);
	}
	else if (i == "s") {
		control_chan = new SHMRequestChannel("control", RequestChannel::CLIENT_SIDE, m);
	}
	else {
		cout << "invalid ipc" << endl;
	}

	RequestChannel* chan = control_chan;
    vector<RequestChannel*> channels;

	cout << "Control pipe connected CLIENT_SIDE" << endl;

    char buf[MAX_MESSAGE]; // 256
	
	char buf2[40];
	for (int j = 0; j < c; ++j) {
		//cout << "Requesting new channel CLIENT_SIDE" << endl;
		MESSAGE_TYPE x = NEWCHANNEL_MSG;
		chan->cwrite(&x, sizeof(MESSAGE_TYPE));
		chan->cread(&buf2, 40);
		//cout << "New channel name " << buf2 << " CLIENT_SIDE" << endl;
		if (i == "f") {
			channels.push_back(new FIFORequestChannel(buf2, RequestChannel::CLIENT_SIDE));
		}
		else if (i == "q") {
			channels.push_back(new MQRequestChannel(buf2, RequestChannel::CLIENT_SIDE, m));
		}
		else if (i == "s") {
			channels.push_back(new SHMRequestChannel(buf2, RequestChannel::CLIENT_SIDE, m));
		}
		
	}

	// update channel reference to new main data channel
	if (c != 0) {
		chan = channels[1];
	}

	// Single datapoint
	if (single) {
        datamsg x(p, t, e);
        memcpy(buf, &x, sizeof(datamsg));
        auto start = high_resolution_clock::now();
        chan->cwrite(buf, sizeof(datamsg)); // question
        double reply;
        chan->cread(&reply, sizeof(double)); //answer
        cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
        cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;
	}

	// Multiple datapoints (whole file)
	else if (multiple){
		if (c == 0) {
			ofstream fs("received/x1.csv");
            cout << "Writing multiple datapoints ";
            auto start = high_resolution_clock::now();
            for (t = 0; t < 4; t += 0.004) {
                if ((int)(t /0.004) % 100 == 0) { cout << "." << flush;}
                datamsg x(p, t, 1);
                double dpt1, dpt2;
                
                chan->cwrite(&x, sizeof(datamsg)); // question
                chan->cread(&dpt1, sizeof(double)); //answer

                x.ecgno = 2;

                chan->cwrite(&x, sizeof(datamsg)); // question
            	chan->cread(&dpt2, sizeof(double)); //answer

                fs << t << ", " << dpt1 << ", " << dpt2 << "\n";
            }
            cout << endl;
            cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
            fs.close();
		}
		auto start = high_resolution_clock::now();
        for (int i = 0; i < c; ++i) {
            ofstream fs("received/x" + std::to_string(i + 1) + ".csv");
            cout << "Writing multiple datapoints ";
            
            for (t = 0; t < 4; t += 0.004) {
                if ((int)(t /0.004) % 100 == 0) { cout << "." << flush;}
                datamsg x(p, t, 1);
                double dpt1, dpt2;
                
                channels[i]->cwrite(&x, sizeof(datamsg)); // question
                channels[i]->cread(&dpt1, sizeof(double)); //answer

                x.ecgno = 2;

                channels[i]->cwrite(&x, sizeof(datamsg)); // question
            	channels[i]->cread(&dpt2, sizeof(double)); //answer

                fs << t << ", " << dpt1 << ", " << dpt2 << "\n";
            }
            cout << endl;
            
            fs.close();
        }
		cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
	}
	
	else if (!filename.empty()) {
		int len = sizeof(filemsg) + (filename.size() + 1);
		cout << "Requesting file " << filename << endl;

		// Get filesize
		filemsg fm(0, 0);

		char* buf2 = new char[len];
		memcpy(buf2, &fm, sizeof(filemsg));
		strcpy(buf2 + sizeof(filemsg), filename.c_str());
		chan->cwrite(buf2, len);

		__int64_t reply;
		chan->cread(&reply, sizeof(__int64_t));
		//cout << "File size of \"" << filename << "\" is " << reply << " bytes" << endl;
		
		int chunks = floor(reply / m);
		int length = m;
		
		
		//cout << "File transfer in " << chunks + 1 << " requests" << endl;
		

		string out_file = "received/" + filename;
		ofstream ofs(out_file, ios::binary);

		if (!ofs) {
			cout << "Error: Filestream not started" << endl;
		}
		else {
			//cout << "Creating output file \"" << out_file << "\"" << endl;
		}

		auto start = high_resolution_clock::now();
		for (int i = 0; i < chunks + 1; ++i) {
			//cout << "Sending request " << i + 1 << " of " << chunks + 1 << endl;
			// Update filemsg
			((filemsg*)buf2)->offset = i * m;
			if (i == chunks) {
				// Calculate size of last (partial) chunk
				length = reply % chunks;
			}
			((filemsg*)buf2)->length = length;

			// send chunk request
			if (c == 0) {
				chan->cwrite(buf2, len);
			}
			else {
				channels[i%c]->cwrite(buf2, len);
			}
			
			
			// read reply and write results to file
			char* data = new char[m];
			if (c == 0) {
				chan->cread(data, length);
			}
			else {
				channels[i%c]->cread(data, length);
			}
			ofs.write(data, length);
			delete[] data;

		}
		ofs.close();
		delete[] buf2;

		cout << "Execution time: " << duration_cast<microseconds>(high_resolution_clock::now() - start).count() << "μs" << endl;
	}
	

	// closing control channel    
	//cout << "closing channel \"" << chan->name() << "\"" << endl;
	MESSAGE_TYPE quit = QUIT_MSG;
	control_chan->cwrite(&quit, sizeof(MESSAGE_TYPE));
	delete control_chan;

	// closing data channels   
	for (RequestChannel* channel: channels) {
		//cout << "closing channel \"" << channel->name() << "\"" << endl;
		channel->cwrite(&quit, sizeof(MESSAGE_TYPE));
        delete channel;
	}

}