#include <fstream>
#include <iostream>
#include <thread>
#include <sys/time.h>
#include <sys/wait.h>

#include "BoundedBuffer.h"
#include "common.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "FIFORequestChannel.h"

#define RED     "\033[1;31m"
#define GREEN	"\033[1;32m"
#define NC      "\033[0m"

// ecgno to use for datamsgs
#define ECGNO 1

using namespace std;

struct response {
    int p_no;
    float data;
};

/*  
    take a patient num
    for n requrests, produce datamsg(num, time, ECGNO), and push to request_buffer
            - time depends on request number, time = n * 0.004
*/
void patient_thread_function (BoundedBuffer* request_buffer, int p_no , int n) {
    
    for (int i = 0; i < n; i++) {
        datamsg msg = datamsg(p_no, i * 0.004, ECGNO);
        //cerr << "Patient thread request: " << msg.mtype << " " << msg.person << " " << msg.seconds << endl;
        request_buffer->push((char*) &msg, sizeof(datamsg));
    }
}

/*
    get file size
    open output file; allocate memory of file fseek; close file
    while offest < file_size
        - produce file_mgs and curent offset + filename and push to request buffer
        - incriment offset, careful with final message
*/
void file_thread_function (BoundedBuffer* request_buffer, FIFORequestChannel* chan, int buffer_size, string filename) {
    
    filemsg fm(0, 0);
    char msg[sizeof(filemsg) + filename.size() + 1];
    memcpy(msg, &fm, sizeof(filemsg));
    strcpy(msg + sizeof(filemsg), filename.c_str());
    chan->cwrite(msg, sizeof(msg));
    __int64_t file_size;
    chan->cread(&file_size, sizeof(__int64_t));

    FILE* fp = fopen(("received/" + filename).c_str(), "w");
    fseek(fp, file_size, SEEK_SET);
    fclose(fp);



    int chunks = floor(file_size / buffer_size);
	int length = buffer_size;
    for (int i = 0; i < chunks + 1; ++i) {
        if (i == chunks) {
            length = file_size % chunks;
        }
        
        ((filemsg*)msg)->offset = i * buffer_size;
        ((filemsg*)msg)->length = length;

        //cout << i << "\tOffset : " << ((filemsg*)msg)->offset << "\t\tLength : " << ((filemsg*)msg)->length << endl;

        request_buffer->push(msg, sizeof(msg));
    }
}

/*
    forever
        pop messag from request_buffer
        determine msg type by casting to datamessage and checking m


        send request to server through FIFO channel
        collect response

        if QUIT:
            - end execution
        if DATA:
            - create pair of person number and server response
            - send pair to response buffer
        if FILE:
            - collect filename from msg popped from buffer
            - open file in correct mode (update)
            - fseek(SEEK_SET) to offset of filemsg
            - write buffer from the server
*/
void worker_thread_function (BoundedBuffer* request_buffer, BoundedBuffer* response_buffer, FIFORequestChannel* fifo_channel, int m) {
    
    while (true) {

        char request[m];
        request_buffer->pop(request, m);
        MESSAGE_TYPE m = *((MESSAGE_TYPE*) request);
        
        
        if (m == DATA_MSG) {
            fifo_channel->cwrite((datamsg*) request, sizeof(datamsg));
            double data;
            fifo_channel->cread(&data, sizeof(double));

            response r = {((datamsg*)request)->person, data};
            response_buffer->push((char*) &r, sizeof(response));
        }
        else if (m == FILE_MSG) {

            filemsg* fm = (filemsg*) request;

            string filename = (char*)(fm + 1);
            //cout << GREEN << "\tOffset : " << fm->offset << "\t\tLength : " << fm->length << NC << endl;
            fifo_channel->cwrite(request, sizeof(request));
            
            char data[fm->length];
            fifo_channel->cread(&data, fm->length);

            FILE* fp = fopen(("received/" + filename).c_str(), "r+");

            fseek(fp, fm->offset, SEEK_SET);
            fwrite(data, fm->length, 1, fp);
            fclose(fp);            
            
        }
        else if (m == QUIT_MSG) {
            fifo_channel->cwrite((datamsg*) request, sizeof(datamsg));
            return;
        }
    }

}

/*
    forever loop
        pop reponse from response_buffer
        call HC::update(reponse person number, response data)
*/
void histogram_thread_function (BoundedBuffer* response_buffer, HistogramCollection* hc) {
    while (true) {
        response r;
        response_buffer->pop((char*) &r, sizeof(response));

        // p_no == -1 -> quit_msg
        if(r.p_no < 0) {
            return;
        }
        else {
            hc->update(r.p_no, r.data);
        }
    }
}


int main (int argc, char* argv[]) {
    int n = 1000;	// default number of requests per "patient"
    int p = 10;		// number of patients [1,15]
    int w = 100;	// default number of worker threads
	int h = 20;		// default number of histogram threads
    int b = 20;		// default capacity of the request buffer (should be changed)
	int m = MAX_MESSAGE;	// default capacity of the message buffer
	string f = "";	// name of file to be transferred
    
    // read arguments
    int opt;
	while ((opt = getopt(argc, argv, "n:p:w:h:b:m:f:")) != -1) {
		switch (opt) {
			case 'n':
				n = atoi(optarg);
                break;
			case 'p':
				p = atoi(optarg);
                break;
			case 'w':
				w = atoi(optarg);
                break;
			case 'h':
				h = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
                break;
			case 'm':
				m = atoi(optarg);
                break;
			case 'f':
				f = optarg;
                break;
		}
	}
    
	// fork and exec the server
    int pid = fork();
    if (pid == 0) {
        execl("./server", "./server", "-m", (char*) to_string(m).c_str(), nullptr);
    }
    
	// initialize overhead (including the control channel)
	FIFORequestChannel* chan = new FIFORequestChannel("control", FIFORequestChannel::CLIENT_SIDE);
    BoundedBuffer request_buffer(b);
    BoundedBuffer response_buffer(b);
	HistogramCollection hc;

    // vector of patient threads (if data, p elements; if file, 1 filethread)
    vector<thread> patient_threads;
    // array of FIFOs (w elements)
    vector<FIFORequestChannel*> fifo_channels;
    // array of worker threads (w elements)
    vector<thread> worker_threads;
    // array of histogram_threads (if data, h elements, if;file, zero elements)
    vector<thread> histogram_threads;

    // making histograms and adding to collection
    for (int i = 0; i < p; i++) {
        Histogram* h = new Histogram(10, -2.0, 2.0);
        hc.add(h);
    }
	
	// record start time
    struct timeval start, end;
    gettimeofday(&start, 0);

    /* create all threads here */

    // if DATA, create p patient threads (store in patient array)
    if(f.empty()) {
        for (int i = 0; i < p; i++) {
            //cerr << "Create patient thread " << i << endl;
            patient_threads.push_back(thread(patient_thread_function, &request_buffer, i + 1, n));
        }
    }

    // create w worker_threads (store worker array)
    for (int i = 0; i < w; i++) {
        // send new channel request & join from client side
        char buf[40];
        MESSAGE_TYPE n = NEWCHANNEL_MSG;
		chan->cwrite(&n, sizeof(MESSAGE_TYPE));
		chan->cread(&buf, sizeof(buf));
        FIFORequestChannel* thread_chan = new FIFORequestChannel(buf, FIFORequestChannel::CLIENT_SIDE);
        worker_threads.push_back(thread(worker_thread_function, &request_buffer, &response_buffer, thread_chan, m));
        fifo_channels.push_back(thread_chan);
    }

    // if FILE, create 1 file_thread (store in patient array)
    if (!f.empty()) {
        patient_threads.push_back(thread(file_thread_function, &request_buffer, chan, m, f));
    }

    // if DATA, create h hist_threads (store hist array)
    if(f.empty()) {
        for (int i = 0; i < h; i++) {
            histogram_threads.push_back(thread(histogram_thread_function, &response_buffer, &hc));
        }
    }

	/* join all threads here */

    // join patient threads
    if(f.empty()) {
        for (int i = 0; i < p; i++) {
            patient_threads[i].join();
        }
    }

    // join file thread
    else {
        patient_threads[0].join();
    }

    // push w quit_msg to request buffer
    for (int i = 0; i < w; i++) {
        MESSAGE_TYPE q = QUIT_MSG;
        request_buffer.push((char*) &q, sizeof(MESSAGE_TYPE));
    }

    // join worker threads
    for (int i = 0; i < w; i++) {
        worker_threads[i].join();
    }

    // push h quit_msg to response buffer
    response quit_pair = {-1, 0.0};
    for (int i = 0; i < h; i++) {
        response_buffer.push((char*) &quit_pair, sizeof(response));
    }

    // join histogram threads
    if (f.empty()) {
        for (int i = 0; i < h; i++) {
            histogram_threads[i].join();
        }
    }

	// record end time
    gettimeofday(&end, 0);

    // print the results
	if (f == "") {
		hc.print();
	}
    int secs = ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) / ((int) 1e6);
    int usecs = (int) ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) % ((int) 1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;


    // deallocate channel references    
    for(size_t i = 0; i < fifo_channels.size(); i++) {
        delete fifo_channels[i];
    }
    
	// quit and close control channel
    MESSAGE_TYPE q = QUIT_MSG;
    chan->cwrite ((char *) &q, sizeof (MESSAGE_TYPE));
    cout << "All Done!" << endl;
    delete chan;

	// wait for server to exit
	wait(nullptr);
}
