#ifndef _BOUNDEDBUFFER_H_
#define _BOUNDEDBUFFER_H_

#include <queue>
#include <vector>
#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <assert.h>
#include <string.h>


class BoundedBuffer {
private:

	int cap;

	std::queue<std::vector<char>> q;

	std::condition_variable data_available;
	std::condition_variable slot_available;
	
	std::mutex m; 
	
public:
	BoundedBuffer (int _cap);
	~BoundedBuffer ();

	void push (char* msg, int size);
	int pop (char* msg, int size);

	size_t size ();
};

#endif
